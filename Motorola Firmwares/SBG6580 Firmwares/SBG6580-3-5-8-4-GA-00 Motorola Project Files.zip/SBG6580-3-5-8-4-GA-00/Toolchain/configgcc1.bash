#!/bin/sh

# edit the gnu version you plan to build
gnuversion=3.2.1
#gnuversion=3.4.3

#edit your target
target=mipsisa32-elf
#target=x86_64-rhel4
#target=x86_64-unknown-linux-gnu

# set your source and destination directories
source_dir=/sb/users/mgi853/source/gcc-${gnuversion}
prefix_dir=/sb/users/mgi853/OSS/opt/gcc-${gnuversion}

export CFLAGS="-O2 -ffunction-sections"
export CXXFLAGS="-O2 -ffunction-sections"

#  If building for native Linux, comment this out
#if [ ! -e $prefix_dir/bin/mipsisa32-elf-as ] ; then
#   echo "Error: You need to have a MIPS assembler in $prefix_dir/bin."
#   exit
#fi

PATH="${prefix_dir}/bin:$PATH"


time ${source_dir}/configure \
   --target=${target}         \
   --prefix=${prefix_dir}     \
   --enable-languages=c,c++   \
   --enable-gofast            \
   --with-gnu-as              \
   --with-gnu-ld              \
   --with-newlib              \
   --with-gxx-include-dir=${prefix_dir}/${target}/include \
   -v 2>&1 | tee configure.out

if [ $gnuversion == 3.4.3 ] ; then
   make configure-gcc 2>&1 | tee configure-gcc.out
   cd gcc
   pwd
   echo "Editing gcc Makefile to use the right library path."
   sed -e "/LIBICONV_DEP/s^$^\nLD_LIBRARY_PATH=/usr/local/lib^" \
       -e "/program_transform_name/s/\$\$t/'\${program_transform_name}'/" Makefile >Makefile.new
   if [ ! -e Makefile.old ] ; then
      mv Makefile Makefile.old
   else
      rm Makefile
   fi
   mv Makefile.new Makefile
else
   cd gcc

   echo "Editing gcc Makefile to build only MIPS32/soft-float libraries."
   sed \
      -e "/MULTILIB_OPTIONS =/s/.*/MULTILIB_OPTIONS = msoft-float EB mips32/" \
      -e "/MULTILIB_DIRNAMES =/s/.*/MULTILIB_DIRNAMES = soft-float eb mips32/" \
      Makefile >Makefile.new

   mv Makefile Makefile.old
   mv Makefile.new Makefile
fi

echo "Done.  Build with:  make -w all install 2>&1 | tee make.out"

