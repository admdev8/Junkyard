#!/bin/sh

# you need to comment out one pair of utilversion and gnuversion depending on the version you are working on
utilversion=2.13.1
gnuversion=3.2.1
#utilversion=2.17
#gnuversion=3.4.3

# you need to comment out targets depending on your needs
target=mipsisa32-elf
#target=x86_64-rhel4
#target=x86_64-unknown-linux-gnu

# you need to set your source and destinatin directories
source_dir=/sb/users/mgi853/source/binutils-${utilversion}
prefix_dir=/sb/users/mgi853/OSS/opt/gcc-${gnuversion}

export CFLAGS="-O2 -ffunction-sections"
export CXXFLAGS="-O2 -ffunction-sections"

#comment this out if you are building an intermediate compiler for native Linux
#if [ ! -e $prefix_dir/bin/mipsisa32-elf-as ] ; then
#   echo "Error: You need to have a MIPS assembler in $prefix_dir/bin."
#fi

PATH="${prefix_dir}/bin:$PATH"


time ${source_dir}/configure \
   --target=${target}         \
   --prefix=${prefix_dir}     \
   -v 2>&1 | tee configure.out

echo "Done.  Build with:  make -w all install 2>&1 | tee make.out"


